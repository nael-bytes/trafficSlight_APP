declare module '@env' {
    export const GOOGLE_MAPS_API_KEY: string;
    export const LOCALHOST_IP: string;
} 